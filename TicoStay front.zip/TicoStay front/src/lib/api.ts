const API_URL = (import.meta.env.VITE_API_URL ?? 'http://localhost:5000/api/v1').replace(/\/$/, '')

const TOKEN_KEY = 'tico-token'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token: string | null) {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token)
    return
  }

  localStorage.removeItem(TOKEN_KEY)
}

type JsonBody = object | unknown[] | null

type ApiOptions = Omit<RequestInit, 'body'> & {
  body?: BodyInit | JsonBody
}

function isFormData(value: unknown): value is FormData {
  return typeof FormData !== 'undefined' && value instanceof FormData
}

function isBodyInit(value: unknown): value is BodyInit {
  return (
    typeof value === 'string' ||
    value instanceof Blob ||
    value instanceof ArrayBuffer ||
    ArrayBuffer.isView(value) ||
    value instanceof URLSearchParams ||
    isFormData(value) ||
    value instanceof ReadableStream
  )
}

function normalizePath(path: string) {
  return path.startsWith('/') ? path : `/${path}`
}

export async function api<T>(path: string, options: ApiOptions = {}): Promise<T> {
  const token = getToken()
  const headers = new Headers(options.headers ?? {})
  const method = options.method ?? 'GET'

  let body: BodyInit | undefined

  if (options.body !== undefined) {
    if (isFormData(options.body)) {
      body = options.body
    } else if (isBodyInit(options.body)) {
      body = options.body
    } else {
      headers.set('Content-Type', 'application/json')
      body = JSON.stringify(options.body)
    }
  }

  if (token) {
    headers.set('Authorization', `Bearer ${token}`)
  }

  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json')
  }

  const response = await fetch(`${API_URL}${normalizePath(path)}`, {
    ...options,
    method,
    headers,
    body,
  })

  const rawText = await response.text()

  let payload: unknown = null

  if (rawText) {
    try {
      payload = JSON.parse(rawText)
    } catch {
      payload = rawText
    }
  }

  if (!response.ok) {
    const errorPayload =
      payload && typeof payload === 'object' ? (payload as Record<string, unknown>) : null

    const message =
      (errorPayload?.message as string | undefined) ||
      (errorPayload?.error as string | undefined) ||
      response.statusText ||
      'Error en la petición'

    throw new Error(message)
  }

  if (
    payload &&
    typeof payload === 'object' &&
    'data' in (payload as Record<string, unknown>)
  ) {
    return (payload as { data: T }).data
  }

  return payload as T
}

export { API_URL, TOKEN_KEY }