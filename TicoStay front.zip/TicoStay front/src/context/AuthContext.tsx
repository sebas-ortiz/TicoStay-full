/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext, useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { api, getToken, setToken } from '../lib/api'

export type UserRole = 'guest' | 'user' | 'admin'

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<User>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
  isAuthenticated: boolean
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const USER_KEY = 'tico-user'

function normalizeUser(data: unknown): User | null {
  if (!data || typeof data !== 'object') return null

  const raw = data as Record<string, unknown>

  const id =
    typeof raw.id === 'string'
      ? raw.id
      : typeof raw._id === 'string'
        ? raw._id
        : null

  const name = typeof raw.name === 'string' ? raw.name : null
  const email = typeof raw.email === 'string' ? raw.email : null
  const role =
    raw.role === 'admin' || raw.role === 'user' || raw.role === 'guest'
      ? raw.role
      : 'user'

  const avatar = typeof raw.avatar === 'string' ? raw.avatar : undefined

  if (!id || !name || !email) return null

  return {
    id,
    name,
    email,
    role,
    avatar,
  }
}

function getStoredUser(): User | null {
  try {
    const stored = localStorage.getItem(USER_KEY)
    if (!stored) return null

    const parsed = JSON.parse(stored)
    const normalized = normalizeUser(parsed)

    if (!normalized) {
      localStorage.removeItem(USER_KEY)
      return null
    }

    return normalized
  } catch {
    localStorage.removeItem(USER_KEY)
    return null
  }
}

function saveUser(user: User | null) {
  if (!user) {
    localStorage.removeItem(USER_KEY)
    return
  }

  localStorage.setItem(USER_KEY, JSON.stringify(user))
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => getStoredUser())
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false

    const boot = async () => {
      const token = getToken()

      if (!token) {
        if (!cancelled) setLoading(false)
        return
      }

      try {
        const meResponse = await api<User>('/auth/me')
        const me = normalizeUser(meResponse)

        if (!me) {
          throw new Error('Usuario invalido')
        }

        if (!cancelled) {
          setUser(me)
          saveUser(me)
        }
      } catch {
        setToken(null)
        saveUser(null)

        if (!cancelled) {
          setUser(null)
        }
      } finally {
        if (!cancelled) {
          setLoading(false)
        }
      }
    }

    boot()

    return () => {
      cancelled = true
    }
  }, [])

  const login = async (email: string, password: string): Promise<User> => {
  setLoading(true)

  try {
    const res = await api<{ user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: { email, password },
    })

    const normalizedUser = normalizeUser(res.user)

    if (!res.token || !normalizedUser) {
      throw new Error('Respuesta inválida del servidor')
    }

    setToken(res.token)
    setUser(normalizedUser)
    saveUser(normalizedUser)

    return normalizedUser
  } catch (error) {
    setToken(null)
    setUser(null)
    saveUser(null)
    throw error
  } finally {
    setLoading(false)
  }
}



  const register = async (name: string, email: string, password: string) => {
    setLoading(true)

    try {
      const res = await api<{ user: User; token: string }>('/auth/register', {
        method: 'POST',
        body: { name, email, password },
      })

      const normalizedUser = normalizeUser(res.user)

      if (!res.token || !normalizedUser) {
        throw new Error('Respuesta inválida del servidor')
      }

      setToken(res.token)
      setUser(normalizedUser)
      saveUser(normalizedUser)
    } catch (error) {
      setToken(null)
      setUser(null)
      saveUser(null)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setToken(null)
    setUser(null)
    saveUser(null)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        isAuthenticated: !!user,
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)

  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider')
  }

  return ctx
}