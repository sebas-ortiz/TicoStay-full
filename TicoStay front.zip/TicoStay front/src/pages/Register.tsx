import { useMemo, useState } from 'react'
import type { ChangeEvent, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  Eye,
  EyeOff,
  Leaf,
  Mail,
  Lock,
  User,
  AlertCircle,
  Check,
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'

type RegisterForm = {
  name: string
  email: string
  password: string
  confirm: string
}

const INITIAL_FORM: RegisterForm = {
  name: '',
  email: '',
  password: '',
  confirm: '',
}

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState<RegisterForm>(INITIAL_FORM)
  const [showPass, setShowPass] = useState(false)
  const [showConfirmPass, setShowConfirmPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const update =
    (key: keyof RegisterForm) => (e: ChangeEvent<HTMLInputElement>) => {
      const value = e.target.value

      setForm(current => ({
        ...current,
        [key]: value,
      }))

      if (error) {
        setError('')
      }
    }

  const passwordStrength = useMemo(() => {
    const password = form.password
    if (!password) return 0

    let score = 0
    if (password.length >= 8) score++
    if (/[A-Z]/.test(password)) score++
    if (/[0-9]/.test(password)) score++
    if (/[^A-Za-z0-9]/.test(password)) score++

    return score
  }, [form.password])

  const strengthColors = ['', '#ef4444', '#f97316', '#eab308', '#22c55e']
  const strengthLabels = ['', 'Muy débil', 'Débil', 'Buena', 'Segura']

  const passwordsMatch = form.confirm.length > 0 && form.confirm === form.password

  const validateForm = () => {
    const trimmedName = form.name.trim()
    const trimmedEmail = form.email.trim()

    if (!trimmedName) {
      return 'Ingresa tu nombre completo.'
    }

    if (trimmedName.length < 2) {
      return 'El nombre debe tener al menos 2 caracteres.'
    }

    if (!trimmedEmail) {
      return 'Ingresa tu correo electrónico.'
    }

    if (!/\S+@\S+\.\S+/.test(trimmedEmail)) {
      return 'Ingresa un correo electrónico válido.'
    }

    if (!form.password) {
      return 'Ingresa una contraseña.'
    }

    if (form.password.length < 6) {
      return 'La contraseña debe tener al menos 6 caracteres.'
    }

    if (form.password !== form.confirm) {
      return 'Las contraseñas no coinciden.'
    }

    return ''
  }

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (loading) return

    const validationError = validateForm()

    if (validationError) {
      setError(validationError)
      return
    }

    setError('')
    setLoading(true)

    try {
      await register(form.name.trim(), form.email.trim().toLowerCase(), form.password)
      setForm(INITIAL_FORM)
      navigate('/')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al crear la cuenta. Intenta de nuevo.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex">
      <div
        className="hidden lg:flex lg:w-1/2 flex-col items-center justify-center relative overflow-hidden"
        style={{
          background:
            'linear-gradient(145deg, var(--forest-mid) 0%, var(--turquoise) 100%)',
        }}
      >
        <img
          src="https://images.unsplash.com/photo-1501117716987-c8c394bb29df?w=900&q=85"
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
          style={{ opacity: 0.15 }}
        />

        <div className="relative z-10 text-center px-12">
          <div className="w-16 h-16 rounded-2xl bg-white/15 flex items-center justify-center mx-auto mb-6">
            <Leaf size={32} style={{ color: 'var(--forest-pale)' }} />
          </div>

          <h2
            className="text-4xl font-bold text-white mb-4"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            Únete a la aventura
          </h2>

          <p className="text-white/70 text-lg leading-relaxed max-w-sm">
            Crea tu cuenta y empieza a descubrir los mejores alojamientos de Costa Rica.
          </p>

          <div className="mt-10 flex flex-col gap-3">
            {[
              '✓  Reserva directa sin intermediarios',
              '✓  Acceso a ofertas exclusivas',
              '✓  Gestiona todas tus reservas',
              '✓  Soporte en español 24/7',
            ].map(item => (
              <div
                key={item}
                className="p-3 rounded-[var(--radius-md)] text-left text-sm"
                style={{
                  background: 'rgba(255,255,255,0.1)',
                  color: 'rgba(255,255,255,0.85)',
                  backdropFilter: 'blur(8px)',
                }}
              >
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div
        className="w-full lg:w-1/2 flex items-center justify-center p-8"
        style={{ background: 'var(--bg)' }}
      >
        <div className="w-full max-w-md animate-scale-in">
          <Link to="/" className="flex items-center gap-2 mb-8 lg:hidden no-underline">
            <div className="w-8 h-8 rounded-lg bg-[var(--forest-light)] flex items-center justify-center">
              <Leaf size={16} className="text-white" />
            </div>
            <span
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: '1.25rem',
                fontWeight: 700,
                color: 'var(--text-primary)',
              }}
            >
              Tico<span style={{ color: 'var(--forest-light)' }}>Stay</span>
            </span>
          </Link>

          <h2
            className="text-3xl font-bold mb-1"
            style={{ fontFamily: 'var(--font-display)', color: 'var(--text-primary)' }}
          >
            Crea tu cuenta
          </h2>

          <p className="mb-8" style={{ color: 'var(--text-muted)' }}>
            Comienza a explorar Costa Rica desde hoy.
          </p>

          {error && (
            <div
              className="flex items-center gap-2 p-3 rounded-[var(--radius-md)] mb-5 text-sm"
              style={{
                background: 'rgba(239,68,68,0.1)',
                color: '#ef4444',
                border: '1px solid rgba(239,68,68,0.2)',
              }}
            >
              <AlertCircle size={16} /> {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label
                className="block text-sm font-semibold mb-1.5"
                style={{ color: 'var(--text-secondary)' }}
              >
                Nombre completo
              </label>

              <div className="relative">
                <User
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }}
                />
                <input
                  type="text"
                  value={form.name}
                  onChange={update('name')}
                  placeholder="Tu nombre"
                  required
                  autoComplete="name"
                  className="input-field pl-9"
                />
              </div>
            </div>

            <div>
              <label
                className="block text-sm font-semibold mb-1.5"
                style={{ color: 'var(--text-secondary)' }}
              >
                Correo electrónico
              </label>

              <div className="relative">
                <Mail
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }}
                />
                <input
                  type="email"
                  value={form.email}
                  onChange={update('email')}
                  placeholder="tu@correo.com"
                  required
                  autoComplete="email"
                  className="input-field pl-9"
                />
              </div>
            </div>

            <div>
              <label
                className="block text-sm font-semibold mb-1.5"
                style={{ color: 'var(--text-secondary)' }}
              >
                Contraseña
              </label>

              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }}
                />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={form.password}
                  onChange={update('password')}
                  placeholder="Mín. 6 caracteres"
                  required
                  autoComplete="new-password"
                  className="input-field pl-9 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(current => !current)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{
                    color: 'var(--text-muted)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>

              {form.password && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4].map(index => (
                      <div
                        key={index}
                        className="h-1 flex-1 rounded-full transition-all duration-300"
                        style={{
                          background:
                            index <= passwordStrength
                              ? strengthColors[passwordStrength]
                              : 'var(--border)',
                        }}
                      />
                    ))}
                  </div>

                  <p className="text-xs" style={{ color: strengthColors[passwordStrength] }}>
                    {strengthLabels[passwordStrength]}
                  </p>
                </div>
              )}
            </div>

            <div>
              <label
                className="block text-sm font-semibold mb-1.5"
                style={{ color: 'var(--text-secondary)' }}
              >
                Confirmar contraseña
              </label>

              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }}
                />
                <input
                  type={showConfirmPass ? 'text' : 'password'}
                  value={form.confirm}
                  onChange={update('confirm')}
                  placeholder="Repite tu contraseña"
                  required
                  autoComplete="new-password"
                  className="input-field pl-9 pr-16"
                  style={{
                    borderColor: form.confirm
                      ? passwordsMatch
                        ? '#22c55e'
                        : '#ef4444'
                      : undefined,
                  }}
                />

                {passwordsMatch && (
                  <Check
                    size={16}
                    className="absolute right-9 top-1/2 -translate-y-1/2"
                    style={{ color: '#22c55e' }}
                  />
                )}

                <button
                  type="button"
                  onClick={() => setShowConfirmPass(current => !current)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{
                    color: 'var(--text-muted)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                >
                  {showConfirmPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full justify-center py-3 mt-2"
              style={{ opacity: loading ? 0.7 : 1 }}
            >
              {loading ? 'Creando cuenta…' : 'Crear cuenta gratis'}
            </button>
          </form>

          <p className="text-center mt-6 text-sm" style={{ color: 'var(--text-muted)' }}>
            ¿Ya tienes cuenta?{' '}
            <Link
              to="/iniciar-sesion"
              className="font-semibold no-underline"
              style={{ color: 'var(--accent)' }}
            >
              Inicia sesión
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}