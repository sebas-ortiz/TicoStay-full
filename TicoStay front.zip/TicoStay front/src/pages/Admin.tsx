import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  Home,
  Star,
  Settings,
  LogOut,
  Menu,
  X,
  TrendingUp,
  Calendar,
  DollarSign,
  Eye,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  Leaf,
  Bell,
  Search,
} from 'lucide-react'

import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'
import type { Property } from '../data/properties'

type AdminTab = 'overview' | 'properties' | 'bookings' | 'reviews' | 'settings'

interface DashboardStats {
  totalProperties: number
  activeBookings: number
  monthlyRevenue: number
  occupancyRate: number
  newReviews: number
  pendingApprovals: number
}

interface Booking {
  id: string
  guest: string
  guestName?: string
  property: string
  propertyName?: string
  checkIn: string
  checkOut: string
  status: string
  total: number
}

interface Review {
  id: string
  guest: string
  guestName?: string
  property: string
  propertyName?: string
  rating: number
  comment: string
  date: string
  approved: boolean
}

interface DashboardData {
  stats: DashboardStats
  recentBookings: Booking[]
  pendingReviews: Review[]
  properties: Property[]
}

interface SiteSettings {
  siteName: string
  contactEmail: string
  phone: string
  notifications?: Record<string, boolean>
}

const EMPTY_STATS: DashboardStats = {
  totalProperties: 0,
  activeBookings: 0,
  monthlyRevenue: 0,
  occupancyRate: 0,
  newReviews: 0,
  pendingApprovals: 0,
}

const NAV_ITEMS: { id: AdminTab; label: string; icon: ReactNode }[] = [
  { id: 'overview', label: 'Resumen', icon: <LayoutDashboard size={18} /> },
  { id: 'properties', label: 'Propiedades', icon: <Home size={18} /> },
  { id: 'bookings', label: 'Reservas', icon: <Calendar size={18} /> },
  { id: 'reviews', label: 'Reseñas', icon: <Star size={18} /> },
  { id: 'settings', label: 'Configuración', icon: <Settings size={18} /> },
]

function asObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null
}

function extractArray<T>(payload: unknown, keys: string[]): T[] {
  if (Array.isArray(payload)) {
    return payload as T[]
  }

  const obj = asObject(payload)
  if (!obj) return []

  for (const key of keys) {
    const value = obj[key]

    if (Array.isArray(value)) {
      return value as T[]
    }
  }

  return []
}

function extractObject<T extends Record<string, unknown>>(
  payload: unknown,
  keys: string[],
): T | null {
  const obj = asObject(payload)
  if (!obj) return null

  for (const key of keys) {
    const value = obj[key]
    const candidate = asObject(value)

    if (candidate) {
      return candidate as unknown as T
    }
  }

  return obj as unknown as T
}

function formatDate(date: string) {
  if (!date) return '-'

  const parsed = new Date(date)
  if (Number.isNaN(parsed.getTime())) return date

  return parsed.toLocaleDateString('es-CR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  })
}

function StatusBadge({ status }: { status: string }) {
  const MAP: Record<
    string,
    { label: string; color: string; bg: string; icon: ReactNode }
  > = {
    confirmed: {
      label: 'Confirmada',
      color: 'var(--forest-light)',
      bg: 'rgba(82,183,136,0.12)',
      icon: <CheckCircle size={11} />,
    },
    pending: {
      label: 'Pendiente',
      color: 'var(--gold-dark)',
      bg: 'rgba(233,196,106,0.15)',
      icon: <Clock size={11} />,
    },
    cancelled: {
      label: 'Cancelada',
      color: '#ef4444',
      bg: 'rgba(239,68,68,0.1)',
      icon: <XCircle size={11} />,
    },
  }

  const state = MAP[status] ?? MAP.pending

  return (
    <span className="badge" style={{ color: state.color, background: state.bg }}>
      {state.icon} {state.label}
    </span>
  )
}

function OverviewTab({
  stats,
  recentBookings,
  pendingReviews,
  onApprove,
  onReject,
  processingReviewId,
}: {
  stats: DashboardStats
  recentBookings: Booking[]
  pendingReviews: Review[]
  onApprove: (id: string) => Promise<void>
  onReject: (id: string) => Promise<void>
  processingReviewId: string | null
}) {
  const cards = [
    {
      label: 'Propiedades activas',
      value: stats.totalProperties,
      icon: <Home size={20} />,
      color: 'var(--forest-light)',
      change: 'Inventario actual',
    },
    {
      label: 'Reservas activas',
      value: stats.activeBookings,
      icon: <Calendar size={20} />,
      color: 'var(--turquoise-mid)',
      change: 'Estado actual',
    },
    {
      label: 'Ingresos del mes',
      value: `$${stats.monthlyRevenue.toLocaleString()}`,
      icon: <DollarSign size={20} />,
      color: 'var(--gold)',
      change: 'Facturación mensual',
    },
    {
      label: 'Tasa de ocupación',
      value: `${stats.occupancyRate}%`,
      icon: <TrendingUp size={20} />,
      color: 'var(--earth-light)',
      change: 'Rendimiento general',
    },
  ]

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {cards.map(card => (
          <div
            key={card.label}
            className="rounded-[var(--radius-lg)] p-5"
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              boxShadow: 'var(--shadow-sm)',
            }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
              style={{ background: `${card.color}22`, color: card.color }}
            >
              {card.icon}
            </div>
            <p
              className="text-2xl font-bold mb-0.5"
              style={{
                fontFamily: 'var(--font-display)',
                color: 'var(--text-primary)',
              }}
            >
              {card.value}
            </p>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
              {card.label}
            </p>
            <p className="text-xs mt-1" style={{ color: 'var(--forest-light)' }}>
              {card.change}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div
          className="rounded-[var(--radius-lg)] p-5"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
          }}
        >
          <h3
            className="font-semibold mb-4"
            style={{
              fontFamily: 'var(--font-display)',
              color: 'var(--text-primary)',
            }}
          >
            Reservas recientes
          </h3>

          {recentBookings.length === 0 ? (
            <p style={{ color: 'var(--text-muted)' }}>
              No hay reservas recientes disponibles.
            </p>
          ) : (
            <div className="space-y-3">
              {recentBookings.slice(0, 5).map(booking => (
                <div
                  key={booking.id}
                  className="flex items-center justify-between gap-3 py-2 border-b last:border-0"
                  style={{ borderColor: 'var(--border)' }}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{
                        background: 'var(--bg-subtle)',
                        color: 'var(--accent)',
                      }}
                    >
                      {(booking.guest || booking.guestName || '?').charAt(0)}
                    </div>
                    <div>
                      <p
                        className="text-sm font-medium"
                        style={{ color: 'var(--text-primary)' }}
                      >
                        {booking.guest || booking.guestName}
                      </p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        {booking.property || booking.propertyName}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <p
                      className="text-sm font-semibold"
                      style={{ color: 'var(--text-primary)' }}
                    >
                      ${booking.total.toLocaleString()}
                    </p>
                    <StatusBadge status={booking.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div
          className="rounded-[var(--radius-lg)] p-5"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
          }}
        >
          <h3
            className="font-semibold mb-4"
            style={{
              fontFamily: 'var(--font-display)',
              color: 'var(--text-primary)',
            }}
          >
            Reseñas pendientes
            <span className="ml-2 badge badge-gold">{pendingReviews.length}</span>
          </h3>

          {pendingReviews.length === 0 ? (
            <p style={{ color: 'var(--text-muted)' }}>
              No hay reseñas pendientes.
            </p>
          ) : (
            <div className="space-y-3">
              {pendingReviews.map(review => (
                <div
                  key={review.id}
                  className="p-3 rounded-[var(--radius-md)]"
                  style={{ background: 'var(--bg-subtle)' }}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p
                      className="text-sm font-medium"
                      style={{ color: 'var(--text-primary)' }}
                    >
                      {review.guest || review.guestName}
                    </p>
                    <span style={{ color: 'var(--gold)', fontSize: '0.75rem' }}>
                      {'★'.repeat(review.rating)}
                    </span>
                  </div>

                  <p
                    className="text-xs mb-2 line-clamp-2"
                    style={{ color: 'var(--text-secondary)' }}
                  >
                    {review.comment}
                  </p>

                  <div className="flex gap-2">
                    <button
                      onClick={() => onApprove(review.id)}
                      disabled={processingReviewId === review.id}
                      className="btn-primary text-xs py-1 px-3"
                    >
                      Aprobar
                    </button>
                    <button
                      onClick={() => onReject(review.id)}
                      disabled={processingReviewId === review.id}
                      className="btn-secondary text-xs py-1 px-3"
                    >
                      Rechazar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function PropertiesTab({
  properties,
  onDelete,
  deletingPropertyId,
}: {
  properties: Property[]
  onDelete: (id: string) => Promise<void>
  deletingPropertyId: string | null
}) {
  const [searchTerm, setSearchTerm] = useState('')

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase()
    if (!q) return properties

    return properties.filter(
      property =>
        property.name.toLowerCase().includes(q) ||
        property.location.toLowerCase().includes(q) ||
        property.region.toLowerCase().includes(q)
    )
  }, [properties, searchTerm])

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div className="relative">
          <input
            type="text"
            placeholder="Buscar propiedad..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="input-field pl-9 py-2 text-sm"
            style={{ width: '260px' }}
          />
          <Search
            size={15}
            className="absolute left-3 top-1/2 -translate-y-1/2"
            style={{ color: 'var(--text-muted)' }}
          />
        </div>
      </div>

      <div
        className="rounded-[var(--radius-lg)] overflow-auto border"
        style={{
          borderColor: 'var(--border)',
          background: 'var(--bg-card)',
        }}
      >
        <table className="w-full min-w-[700px]">
          <thead>
            <tr
              style={{
                borderBottom: '1px solid var(--border)',
                background: 'var(--bg-subtle)',
              }}
            >
              {[
                'Propiedad',
                'Tipo',
                'Ubicación',
                'Precio/noche',
                'Rating',
                'Estado',
                '',
              ].map(header => (
                <th
                  key={header}
                  className="text-left px-4 py-3 text-xs font-semibold whitespace-nowrap"
                  style={{
                    color: 'var(--text-muted)',
                    letterSpacing: '0.04em',
                    textTransform: 'uppercase',
                  }}
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {filtered.map(property => (
              <tr
                key={property.id}
                className="border-b transition-colors"
                style={{ borderColor: 'var(--border)' }}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={property.image}
                      alt=""
                      className="w-10 h-10 rounded-[var(--radius-md)] object-cover"
                    />
                    <div>
                      <p
                        className="text-sm font-medium"
                        style={{ color: 'var(--text-primary)' }}
                      >
                        {property.name}
                      </p>
                      {property.ecoFriendly && (
                        <span
                          className="text-xs"
                          style={{ color: 'var(--forest-light)' }}
                        >
                          🌿 Eco
                        </span>
                      )}
                    </div>
                  </div>
                </td>

                <td className="px-4 py-3">
                  <span className="badge badge-earth text-xs">{property.type}</span>
                </td>

                <td
                  className="px-4 py-3 text-sm"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  {property.region}
                </td>

                <td
                  className="px-4 py-3 text-sm font-semibold"
                  style={{ color: 'var(--text-primary)' }}
                >
                  ${property.price}
                </td>

                <td className="px-4 py-3">
                  <span className="flex items-center gap-1 text-sm">
                    <span style={{ color: 'var(--gold)' }}>★</span>
                    <span style={{ color: 'var(--text-primary)' }}>
                      {property.rating}
                    </span>
                  </span>
                </td>

                <td className="px-4 py-3">
                  <span className="badge badge-green text-xs">Activa</span>
                </td>

                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <Link
                      to={`/propiedad/${property.id}`}
                      className="btn-ghost p-1.5"
                      title="Ver"
                    >
                      <Eye size={14} />
                    </Link>

                    <button
                      onClick={() => onDelete(property.id)}
                      disabled={deletingPropertyId === property.id}
                      className="btn-ghost p-1.5"
                      style={{ color: '#ef4444' }}
                      title="Eliminar"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="text-center py-12" style={{ color: 'var(--text-muted)' }}>
            No se encontraron propiedades.
          </div>
        )}
      </div>
    </div>
  )
}

function BookingsTab({ bookings }: { bookings: Booking[] }) {
  return (
    <div className="animate-fade-in">
      <h2
        className="text-xl font-bold mb-5"
        style={{
          fontFamily: 'var(--font-display)',
          color: 'var(--text-primary)',
        }}
      >
        Reservas
      </h2>

      <div
        className="rounded-[var(--radius-lg)] overflow-auto border"
        style={{
          borderColor: 'var(--border)',
          background: 'var(--bg-card)',
        }}
      >
        <table className="w-full min-w-[700px]">
          <thead>
            <tr
              style={{
                borderBottom: '1px solid var(--border)',
                background: 'var(--bg-subtle)',
              }}
            >
              {[
                'ID',
                'Huésped',
                'Propiedad',
                'Check-in',
                'Check-out',
                'Total',
                'Estado',
              ].map(header => (
                <th
                  key={header}
                  className="text-left px-4 py-3 text-xs font-semibold"
                  style={{
                    color: 'var(--text-muted)',
                    letterSpacing: '0.04em',
                    textTransform: 'uppercase',
                  }}
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {bookings.map(booking => (
              <tr
                key={booking.id}
                className="border-b transition-colors"
                style={{ borderColor: 'var(--border)' }}
              >
                <td
                  className="px-4 py-3 text-xs font-mono"
                  style={{ color: 'var(--text-muted)' }}
                >
                  {booking.id}
                </td>
                <td
                  className="px-4 py-3 text-sm font-medium"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {booking.guest || booking.guestName}
                </td>
                <td
                  className="px-4 py-3 text-sm"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  {booking.property || booking.propertyName}
                </td>
                <td
                  className="px-4 py-3 text-sm"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  {formatDate(booking.checkIn)}
                </td>
                <td
                  className="px-4 py-3 text-sm"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  {formatDate(booking.checkOut)}
                </td>
                <td
                  className="px-4 py-3 text-sm font-semibold"
                  style={{ color: 'var(--text-primary)' }}
                >
                  ${booking.total.toLocaleString()}
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={booking.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {bookings.length === 0 && (
          <div className="text-center py-12" style={{ color: 'var(--text-muted)' }}>
            No hay reservas disponibles.
          </div>
        )}
      </div>
    </div>
  )
}

function ReviewsTab({
  reviews,
  onApprove,
  onReject,
  processingReviewId,
}: {
  reviews: Review[]
  onApprove: (id: string) => Promise<void>
  onReject: (id: string) => Promise<void>
  processingReviewId: string | null
}) {
  return (
    <div className="animate-fade-in">
      <h2
        className="text-xl font-bold mb-5"
        style={{
          fontFamily: 'var(--font-display)',
          color: 'var(--text-primary)',
        }}
      >
        Reseñas
      </h2>

      {reviews.length === 0 ? (
        <div
          className="rounded-[var(--radius-lg)] p-6"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            color: 'var(--text-muted)',
          }}
        >
          No hay reseñas disponibles.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reviews.map(review => (
            <div
              key={review.id}
              className="rounded-[var(--radius-lg)] p-5"
              style={{
                background: 'var(--bg-card)',
                border: `1px solid ${
                  review.approved ? 'var(--border)' : 'rgba(233,196,106,0.3)'
                }`,
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <div className="flex items-start justify-between gap-2 mb-3">
                <div>
                  <p
                    className="font-semibold text-sm"
                    style={{ color: 'var(--text-primary)' }}
                  >
                    {review.guest || review.guestName}
                  </p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    {review.property || review.propertyName} · {formatDate(review.date)}
                  </p>
                </div>

                <span style={{ color: 'var(--gold)', fontSize: '0.875rem' }}>
                  {'★'.repeat(review.rating)}
                </span>
              </div>

              <p
                className="text-sm mb-4 leading-relaxed"
                style={{ color: 'var(--text-secondary)' }}
              >
                {review.comment}
              </p>

              <div className="flex items-center justify-between">
                {review.approved ? (
                  <span className="badge badge-green">
                    <CheckCircle size={11} /> Aprobada
                  </span>
                ) : (
                  <span className="badge badge-gold">
                    <Clock size={11} /> Pendiente
                  </span>
                )}

                {!review.approved && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => onApprove(review.id)}
                      disabled={processingReviewId === review.id}
                      className="btn-primary text-xs py-1.5 px-3"
                    >
                      <CheckCircle size={12} /> Aprobar
                    </button>

                    <button
                      onClick={() => onReject(review.id)}
                      disabled={processingReviewId === review.id}
                      className="btn-secondary text-xs py-1.5 px-3"
                      style={{ borderColor: '#ef4444', color: '#ef4444' }}
                    >
                      <XCircle size={12} /> Rechazar
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function SettingsTab({
  settings,
  onSave,
  saving,
}: {
  settings: SiteSettings
  onSave: (next: SiteSettings) => Promise<void>
  saving: boolean
}) {
  const [form, setForm] = useState<SiteSettings>(settings)

  useEffect(() => {
    setForm(settings)
  }, [settings])

  const update =
    (key: keyof SiteSettings) => (e: React.ChangeEvent<HTMLInputElement>) => {
      setForm(current => ({ ...current, [key]: e.target.value }))
    }

  return (
    <div className="animate-fade-in max-w-2xl">
      <h2
        className="text-xl font-bold mb-6"
        style={{
          fontFamily: 'var(--font-display)',
          color: 'var(--text-primary)',
        }}
      >
        Configuración
      </h2>

      <div
        className="rounded-[var(--radius-lg)] p-6 mb-4"
        style={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border)',
        }}
      >
        <h3
          className="font-semibold mb-4 text-sm"
          style={{
            color: 'var(--text-primary)',
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
          }}
        >
          Información del sitio
        </h3>

        <div className="grid grid-cols-1 gap-4">
          <div>
            <label
              className="block text-sm font-semibold mb-1.5"
              style={{ color: 'var(--text-secondary)' }}
            >
              Nombre del sitio
            </label>
            <input
              type="text"
              value={form.siteName}
              onChange={update('siteName')}
              className="input-field"
            />
          </div>

          <div>
            <label
              className="block text-sm font-semibold mb-1.5"
              style={{ color: 'var(--text-secondary)' }}
            >
              Email de contacto
            </label>
            <input
              type="text"
              value={form.contactEmail}
              onChange={update('contactEmail')}
              className="input-field"
            />
          </div>

          <div>
            <label
              className="block text-sm font-semibold mb-1.5"
              style={{ color: 'var(--text-secondary)' }}
            >
              Teléfono
            </label>
            <input
              type="text"
              value={form.phone}
              onChange={update('phone')}
              className="input-field"
            />
          </div>
        </div>

        <div className="flex items-center gap-3 mt-5">
          <button
            onClick={() => onSave(form)}
            className="btn-primary text-sm py-2"
            disabled={saving}
          >
            {saving ? 'Guardando...' : 'Guardar cambios'}
          </button>
        </div>
      </div>
    </div>
  )
}

export default function Admin() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const [activeTab, setActiveTab] = useState<AdminTab>('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const [stats, setStats] = useState<DashboardStats>(EMPTY_STATS)
  const [properties, setProperties] = useState<Property[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [reviews, setReviews] = useState<Review[]>([])
  const [settings, setSettings] = useState<SiteSettings>({
    siteName: 'TicoStay',
    contactEmail: 'hola@ticostay.cr',
    phone: '+506 2222-3333',
  })

  const [deletingPropertyId, setDeletingPropertyId] = useState<string | null>(null)
  const [processingReviewId, setProcessingReviewId] = useState<string | null>(null)
  const [savingSettings, setSavingSettings] = useState(false)

  const pendingReviews = useMemo(
    () => reviews.filter(review => !review.approved),
    [reviews]
  )

  const loadAdminData = async () => {
    setLoading(true)
    setError('')

    try {
      const [dashboard, bookingsData, reviewsData, settingsData] = await Promise.all([
        api<DashboardData>('/admin/dashboard'),
        api<Booking[]>('/bookings'),
        api<Review[]>('/reviews'),
        api<SiteSettings>('/admin/settings'),
      ])

      setStats(dashboard.stats ?? EMPTY_STATS)
      setProperties(dashboard.properties ?? [])
      setBookings(bookingsData ?? [])
      setReviews(reviewsData ?? [])
      setSettings(settingsData)
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'No se pudo cargar la información del panel.'
      )
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAdminData()
  }, [])

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const handleDeleteProperty = async (id: string) => {
    try {
      setDeletingPropertyId(id)
      await api(`/properties/${id}`, { method: 'DELETE' })

      setProperties(current => current.filter(property => property.id !== id))
      setStats(current => ({
        ...current,
        totalProperties: Math.max(0, current.totalProperties - 1),
      }))
    } catch (err) {
      alert(
        err instanceof Error
          ? err.message
          : 'No se pudo eliminar la propiedad.'
      )
    } finally {
      setDeletingPropertyId(null)
    }
  }

  const handleApproveReview = async (id: string) => {
    try {
      setProcessingReviewId(id)
      await api(`/reviews/${id}/approve`, { method: 'PATCH' })

      setReviews(current =>
        current.map(review =>
          review.id === id ? { ...review, approved: true } : review
        )
      )
    } catch (err) {
      alert(
        err instanceof Error ? err.message : 'No se pudo aprobar la reseña.'
      )
    } finally {
      setProcessingReviewId(null)
    }
  }

  const handleRejectReview = async (id: string) => {
    try {
      setProcessingReviewId(id)
      await api(`/reviews/${id}/reject`, { method: 'PATCH' })

      setReviews(current => current.filter(review => review.id !== id))
    } catch (err) {
      alert(
        err instanceof Error ? err.message : 'No se pudo rechazar la reseña.'
      )
    } finally {
      setProcessingReviewId(null)
    }
  }

  const handleSaveSettings = async (next: SiteSettings) => {
    try {
      setSavingSettings(true)
      const updated = await api<SiteSettings>('/admin/settings', {
        method: 'PUT',
        body: next,
      })
      setSettings(updated)
      alert('Configuración actualizada correctamente.')
    } catch (err) {
      alert(
        err instanceof Error
          ? err.message
          : 'No se pudo guardar la configuración.'
      )
    } finally {
      setSavingSettings(false)
    }
  }

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{ background: 'var(--bg)', fontFamily: 'var(--font-body)' }}
    >
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 z-30 bg-black/50"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed lg:relative inset-y-0 left-0 z-40 flex flex-col w-64 shrink-0 transition-transform duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
        style={{
          background: 'var(--forest)',
          height: '100vh',
          boxShadow: '4px 0 20px rgba(0,0,0,0.15)',
        }}
      >
        <div
          className="flex items-center justify-between p-5 border-b"
          style={{ borderColor: 'rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center gap-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ background: 'var(--forest-light)' }}
            >
              <Leaf size={16} className="text-white" />
            </div>
            <div>
              <p
                style={{
                  fontFamily: 'var(--font-display)',
                  color: 'white',
                  fontWeight: 700,
                  lineHeight: 1,
                  fontSize: '1rem',
                }}
              >
                Tico<span style={{ color: 'var(--forest-pale)' }}>Stay</span>
              </p>
              <p
                style={{
                  color: 'rgba(255,255,255,0.5)',
                  fontSize: '0.65rem',
                  textTransform: 'uppercase',
                  letterSpacing: '0.08em',
                }}
              >
                Admin Panel
              </p>
            </div>
          </div>

          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden"
            style={{
              background: 'none',
              border: 'none',
              color: 'rgba(255,255,255,0.6)',
              cursor: 'pointer',
            }}
          >
            <X size={18} />
          </button>
        </div>

        <div
          className="px-4 py-4 border-b"
          style={{ borderColor: 'rgba(255,255,255,0.08)' }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold"
              style={{ background: 'var(--forest-light)', color: 'white' }}
            >
              {user?.name?.charAt(0) ?? 'A'}
            </div>
            <div className="min-w-0">
              <p
                className="text-sm font-semibold truncate"
                style={{ color: 'white' }}
              >
                {user?.name}
              </p>
              <p
                className="text-xs truncate"
                style={{ color: 'rgba(255,255,255,0.5)' }}
              >
                {user?.email}
              </p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id)
                setSidebarOpen(false)
              }}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] mb-0.5 text-sm font-medium transition-all text-left"
              style={{
                background:
                  activeTab === item.id ? 'rgba(255,255,255,0.12)' : 'transparent',
                color:
                  activeTab === item.id ? 'white' : 'rgba(255,255,255,0.6)',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'var(--font-body)',
              }}
            >
              {item.icon}
              {item.label}

              {item.id === 'reviews' && pendingReviews.length > 0 && (
                <span
                  className="ml-auto text-xs px-1.5 py-0.5 rounded-full"
                  style={{
                    background: 'var(--gold)',
                    color: '#1a1208',
                    fontWeight: 700,
                  }}
                >
                  {pendingReviews.length}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div
          className="p-3 border-t"
          style={{ borderColor: 'rgba(255,255,255,0.08)' }}
        >
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] text-sm transition-all text-left"
            style={{
              background: 'transparent',
              border: 'none',
              color: 'rgba(255,255,255,0.5)',
              cursor: 'pointer',
              fontFamily: 'var(--font-body)',
            }}
          >
            <LogOut size={18} /> Cerrar sesión
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header
          className="flex items-center justify-between px-4 md:px-6 h-14 shrink-0 border-b"
          style={{
            background: 'var(--bg-card)',
            borderColor: 'var(--border)',
          }}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden btn-ghost p-2"
            >
              <Menu size={20} />
            </button>

            <h1
              className="text-base font-semibold"
              style={{
                color: 'var(--text-primary)',
                fontFamily: 'var(--font-display)',
              }}
            >
              {NAV_ITEMS.find(item => item.id === activeTab)?.label}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            <button className="btn-ghost p-2 relative">
              <Bell size={18} />
              <span
                className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
                style={{ background: 'var(--forest-light)' }}
              />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          {loading ? (
            <div
              className="rounded-[var(--radius-lg)] p-6"
              style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border)',
                color: 'var(--text-muted)',
              }}
            >
              Cargando panel administrativo...
            </div>
          ) : error ? (
            <div
              className="rounded-[var(--radius-lg)] p-6"
              style={{
                background: 'var(--bg-card)',
                border: '1px solid rgba(239,68,68,0.2)',
                color: '#ef4444',
              }}
            >
              {error}
              <div className="mt-4">
                <button onClick={loadAdminData} className="btn-primary text-sm py-2">
                  Reintentar
                </button>
              </div>
            </div>
          ) : (
            <>
              {activeTab === 'overview' && (
                <OverviewTab
                  stats={stats}
                  recentBookings={bookings.slice(0, 5)}
                  pendingReviews={pendingReviews.slice(0, 5)}
                  onApprove={handleApproveReview}
                  onReject={handleRejectReview}
                  processingReviewId={processingReviewId}
                />
              )}

              {activeTab === 'properties' && (
                <PropertiesTab
                  properties={properties}
                  onDelete={handleDeleteProperty}
                  deletingPropertyId={deletingPropertyId}
                />
              )}

              {activeTab === 'bookings' && <BookingsTab bookings={bookings} />}

              {activeTab === 'reviews' && (
                <ReviewsTab
                  reviews={reviews}
                  onApprove={handleApproveReview}
                  onReject={handleRejectReview}
                  processingReviewId={processingReviewId}
                />
              )}

              {activeTab === 'settings' && (
                <SettingsTab
                  settings={settings}
                  onSave={handleSaveSettings}
                  saving={savingSettings}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  )
}