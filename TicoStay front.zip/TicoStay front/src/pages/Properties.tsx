import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  SlidersHorizontal,
  X,
  ChevronDown,
  ChevronUp,
  Grid3X3,
  List,
  Search,
} from 'lucide-react'

import PropertyCard from '../components/PropertyCard'
import SearchBar from '../components/SearchBar'
import { api } from '../lib/api'
import { REGIONS, type Property } from '../data/properties'

type SortKey = 'relevance' | 'price-asc' | 'price-desc' | 'rating'

const TYPES: Property['type'][] = [
  'hotel',
  'eco-lodge',
  'villa',
  'cabaña',
  'apartamento',
]

const TYPE_LABELS: Record<Property['type'], string> = {
  hotel: 'Hotel',
  'eco-lodge': 'Eco-Lodge',
  villa: 'Villa',
  cabaña: 'Cabaña',
  apartamento: 'Apartamento',
}

const AMENITY_OPTIONS = [
  'Piscina',
  'Wi-Fi',
  'Playa',
  'Desayuno incluido',
  'Spa',
  'Estacionamiento',
  'Restaurante',
  'Yoga',
]

interface Filters {
  types: Property['type'][]
  regions: string[]
  priceMin: number
  priceMax: number
  minRating: number
  amenities: string[]
  ecoOnly: boolean
}

const DEFAULT_FILTERS: Filters = {
  types: [],
  regions: [],
  priceMin: 0,
  priceMax: 1000,
  minRating: 0,
  amenities: [],
  ecoOnly: false,
}

function toggle<T>(arr: T[], value: T): T[] {
  return arr.includes(value) ? arr.filter(item => item !== value) : [...arr, value]
}

function normalizePropertiesResponse(payload: unknown): Property[] {
  if (Array.isArray(payload)) {
    return payload as Property[]
  }

  if (!payload || typeof payload !== 'object') {
    return []
  }

  const data = payload as Record<string, unknown>

  if (Array.isArray(data.properties)) return data.properties as Property[]
  if (Array.isArray(data.items)) return data.items as Property[]
  if (Array.isArray(data.results)) return data.results as Property[]

  return []
}

export default function Properties() {
  const [searchParams] = useSearchParams()

  const query = (searchParams.get('q') ?? '').trim()
  const regionQP = (searchParams.get('region') ?? '').trim()
  const guestsQP = (searchParams.get('guests') ?? '').trim()
  const checkInQP = (searchParams.get('checkIn') ?? '').trim()
  const checkOutQP = (searchParams.get('checkOut') ?? '').trim()

  const baseFilters = useMemo<Filters>(() => {
    return {
      ...DEFAULT_FILTERS,
      regions: regionQP && regionQP !== 'all' ? [regionQP] : [],
    }
  }, [regionQP])

  const [filters, setFilters] = useState<Filters>(baseFilters)
  const [sort, setSort] = useState<SortKey>('relevance')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [results, setResults] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)

  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    type: true,
    region: true,
    price: true,
    rating: true,
    amenities: false,
    eco: true,
  })

  useEffect(() => {
    setFilters(current => ({
      ...current,
      regions: baseFilters.regions,
    }))
  }, [baseFilters])

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      try {
        setLoading(true)

        const params = new URLSearchParams()

        if (query) params.set('q', query)
        if (filters.regions.length) params.set('region', filters.regions.join(','))
        if (filters.types.length) params.set('type', filters.types.join(','))
        if (filters.ecoOnly) params.set('ecoOnly', 'true')
        if (filters.minRating > 0) params.set('minRating', String(filters.minRating))
        if (filters.priceMin > 0) params.set('minPrice', String(filters.priceMin))
        if (filters.priceMax < 1000) params.set('maxPrice', String(filters.priceMax))
        if (filters.amenities.length) params.set('amenities', filters.amenities.join(','))
        if (sort !== 'relevance') params.set('sort', sort)
        if (guestsQP) params.set('guests', guestsQP)
        if (checkInQP) params.set('checkIn', checkInQP)
        if (checkOutQP) params.set('checkOut', checkOutQP)

        const response = await api<unknown>(`/properties?${params.toString()}`)
        const normalized = normalizePropertiesResponse(response)

        if (!cancelled) {
          setResults(normalized)
        }
      } catch (error) {
        console.error('Error cargando propiedades:', error)

        if (!cancelled) {
          setResults([])
        }
      } finally {
        if (!cancelled) {
          setLoading(false)
        }
      }
    }

    load()

    return () => {
      cancelled = true
    }
  }, [query, filters, sort, guestsQP, checkInQP, checkOutQP])

  const toggleSection = (key: string) => {
    setExpandedSections(current => ({
      ...current,
      [key]: !current[key],
    }))
  }

  const activeFilterCount = useMemo(() => {
    return (
      filters.types.length +
      filters.regions.length +
      (filters.ecoOnly ? 1 : 0) +
      (filters.minRating > 0 ? 1 : 0) +
      filters.amenities.length +
      (filters.priceMin > 0 ? 1 : 0) +
      (filters.priceMax < 1000 ? 1 : 0)
    )
  }, [filters])

  const resetFilters = () => {
    setFilters(baseFilters)
  }

  const pageTitle = query
    ? `Resultados para "${query}"`
    : regionQP && regionQP !== 'all'
      ? regionQP
      : 'Todas las propiedades'

  const SidebarContent = () => (
    <aside className="w-full">
      <div className="flex items-center justify-between mb-6">
        <h3
          className="font-semibold text-base"
          style={{
            color: 'var(--text-primary)',
            fontFamily: 'var(--font-display)',
          }}
        >
          Filtros
        </h3>

        {activeFilterCount > 0 && (
          <button
            onClick={resetFilters}
            className="text-xs flex items-center gap-1"
            style={{
              color: 'var(--accent)',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'var(--font-body)',
            }}
          >
            <X size={12} /> Limpiar ({activeFilterCount})
          </button>
        )}
      </div>

      <FilterSection
        label="Tipo de alojamiento"
        open={expandedSections.type}
        onToggle={() => toggleSection('type')}
      >
        <div className="flex flex-col gap-2">
          {TYPES.map(type => (
            <label key={type} className="flex items-center gap-2.5 cursor-pointer group">
              <input
                type="checkbox"
                checked={filters.types.includes(type)}
                onChange={() =>
                  setFilters(current => ({
                    ...current,
                    types: toggle(current.types, type),
                  }))
                }
                className="w-4 h-4 rounded accent-[var(--accent)]"
              />
              <span
                className="text-sm transition-colors"
                style={{ color: 'var(--text-secondary)' }}
              >
                {TYPE_LABELS[type]}
              </span>
            </label>
          ))}
        </div>
      </FilterSection>

      <FilterSection
        label="Región"
        open={expandedSections.region}
        onToggle={() => toggleSection('region')}
      >
        <div className="flex flex-col gap-2">
          {REGIONS.map(region => (
            <label key={region} className="flex items-center gap-2.5 cursor-pointer group">
              <input
                type="checkbox"
                checked={filters.regions.includes(region)}
                onChange={() =>
                  setFilters(current => ({
                    ...current,
                    regions: toggle(current.regions, region),
                  }))
                }
                className="w-4 h-4 rounded accent-[var(--accent)]"
              />
              <span
                className="text-sm transition-colors"
                style={{ color: 'var(--text-secondary)' }}
              >
                {region}
              </span>
            </label>
          ))}
        </div>
      </FilterSection>

      <FilterSection
        label="Precio por noche"
        open={expandedSections.price}
        onToggle={() => toggleSection('price')}
      >
        <div>
          <div className="flex justify-between text-sm mb-2" style={{ color: 'var(--text-muted)' }}>
            <span>${filters.priceMin}</span>
            <span>{filters.priceMax >= 1000 ? '$1000+' : `$${filters.priceMax}`}</span>
          </div>

          <input
            type="range"
            min={0}
            max={1000}
            step={25}
            value={filters.priceMax}
            onChange={e =>
              setFilters(current => ({
                ...current,
                priceMax: Number(e.target.value),
              }))
            }
            className="w-full accent-[var(--accent)]"
          />
        </div>
      </FilterSection>

      <FilterSection
        label="Calificación mínima"
        open={expandedSections.rating}
        onToggle={() => toggleSection('rating')}
      >
        <div className="flex gap-2 flex-wrap">
          {[0, 3, 4, 4.5].map(rating => (
            <button
              key={rating}
              onClick={() =>
                setFilters(current => ({
                  ...current,
                  minRating: rating,
                }))
              }
              className="px-3 py-1.5 rounded-full text-sm transition-all"
              style={{
                background:
                  filters.minRating === rating ? 'var(--accent)' : 'var(--bg-subtle)',
                color:
                  filters.minRating === rating
                    ? 'var(--accent-fg)'
                    : 'var(--text-secondary)',
                border: '1.5px solid',
                borderColor:
                  filters.minRating === rating ? 'var(--accent)' : 'var(--border)',
                fontFamily: 'var(--font-body)',
                cursor: 'pointer',
              }}
            >
              {rating === 0 ? 'Todos' : `${rating}★`}
            </button>
          ))}
        </div>
      </FilterSection>

      <FilterSection
        label="Sostenibilidad"
        open={expandedSections.eco}
        onToggle={() => toggleSection('eco')}
      >
        <label className="flex items-center gap-2.5 cursor-pointer">
          <input
            type="checkbox"
            checked={filters.ecoOnly}
            onChange={e =>
              setFilters(current => ({
                ...current,
                ecoOnly: e.target.checked,
              }))
            }
            className="w-4 h-4 rounded accent-[var(--accent)]"
          />
          <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
            🌿 Solo eco-friendly
          </span>
        </label>
      </FilterSection>

      <FilterSection
        label="Amenidades"
        open={expandedSections.amenities}
        onToggle={() => toggleSection('amenities')}
      >
        <div className="flex flex-wrap gap-2">
          {AMENITY_OPTIONS.map(amenity => (
            <button
              key={amenity}
              onClick={() =>
                setFilters(current => ({
                  ...current,
                  amenities: toggle(current.amenities, amenity),
                }))
              }
              className="px-2.5 py-1 rounded-full text-xs transition-all"
              style={{
                background: filters.amenities.includes(amenity)
                  ? 'var(--accent)'
                  : 'var(--bg-subtle)',
                color: filters.amenities.includes(amenity)
                  ? 'var(--accent-fg)'
                  : 'var(--text-secondary)',
                border: '1.5px solid',
                borderColor: filters.amenities.includes(amenity)
                  ? 'var(--accent)'
                  : 'var(--border)',
                fontFamily: 'var(--font-body)',
                cursor: 'pointer',
              }}
            >
              {amenity}
            </button>
          ))}
        </div>
      </FilterSection>
    </aside>
  )

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh' }}>
      <div
        className="pt-20 pb-6 border-b"
        style={{ background: 'var(--bg-card)', borderColor: 'var(--border)' }}
      >
        <div className="container">
          <div className="max-w-3xl">
            <SearchBar inline initialValues={{ location: query || regionQP }} />
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
          <div>
            <h1
              className="text-2xl font-bold"
              style={{
                fontFamily: 'var(--font-display)',
                color: 'var(--text-primary)',
              }}
            >
              {pageTitle}
            </h1>
            <p className="text-sm mt-0.5" style={{ color: 'var(--text-muted)' }}>
              {loading
                ? 'Cargando propiedades...'
                : `${results.length} ${
                    results.length === 1
                      ? 'propiedad encontrada'
                      : 'propiedades encontradas'
                  }`}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(open => !open)}
              className="lg:hidden btn-secondary text-sm py-2 flex items-center gap-2"
            >
              <SlidersHorizontal size={15} />
              Filtros{' '}
              {activeFilterCount > 0 && (
                <span className="badge badge-green py-0 px-1.5">{activeFilterCount}</span>
              )}
            </button>

            <select
              value={sort}
              onChange={e => setSort(e.target.value as SortKey)}
              className="input-field py-2 text-sm"
              style={{ minWidth: '160px' }}
            >
              <option value="relevance">Relevancia</option>
              <option value="price-asc">Precio: menor a mayor</option>
              <option value="price-desc">Precio: mayor a menor</option>
              <option value="rating">Mejor calificación</option>
            </select>

            <div
              className="hidden sm:flex rounded-[var(--radius-md)] overflow-hidden border"
              style={{ borderColor: 'var(--border)' }}
            >
              {(['grid', 'list'] as const).map(mode => (
                <button
                  key={mode}
                  onClick={() => setViewMode(mode)}
                  className="p-2 transition-colors"
                  style={{
                    background: viewMode === mode ? 'var(--accent)' : 'var(--bg-card)',
                    color:
                      viewMode === mode
                        ? 'var(--accent-fg)'
                        : 'var(--text-muted)',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                >
                  {mode === 'grid' ? <Grid3X3 size={16} /> : <List size={16} />}
                </button>
              ))}
            </div>
          </div>
        </div>

        {activeFilterCount > 0 && (
          <div className="flex flex-wrap gap-2 mb-5">
            {filters.types.map(type => (
              <FilterChip
                key={type}
                label={TYPE_LABELS[type]}
                onRemove={() =>
                  setFilters(current => ({
                    ...current,
                    types: toggle(current.types, type),
                  }))
                }
              />
            ))}

            {filters.regions.map(region => (
              <FilterChip
                key={region}
                label={region}
                onRemove={() =>
                  setFilters(current => ({
                    ...current,
                    regions: toggle(current.regions, region),
                  }))
                }
              />
            ))}

            {(filters.priceMin > 0 || filters.priceMax < 1000) && (
              <FilterChip
                label={`Precio: $${filters.priceMin} - ${
                  filters.priceMax >= 1000 ? '1000+' : filters.priceMax
                }`}
                onRemove={() =>
                  setFilters(current => ({
                    ...current,
                    priceMin: DEFAULT_FILTERS.priceMin,
                    priceMax: DEFAULT_FILTERS.priceMax,
                  }))
                }
              />
            )}

            {filters.ecoOnly && (
              <FilterChip
                label="Eco-friendly"
                onRemove={() =>
                  setFilters(current => ({
                    ...current,
                    ecoOnly: false,
                  }))
                }
              />
            )}

            {filters.minRating > 0 && (
              <FilterChip
                label={`${filters.minRating}★ mín.`}
                onRemove={() =>
                  setFilters(current => ({
                    ...current,
                    minRating: 0,
                  }))
                }
              />
            )}

            {filters.amenities.map(amenity => (
              <FilterChip
                key={amenity}
                label={amenity}
                onRemove={() =>
                  setFilters(current => ({
                    ...current,
                    amenities: toggle(current.amenities, amenity),
                  }))
                }
              />
            ))}
          </div>
        )}

        <div className="flex gap-8">
          <div
            className="hidden lg:block shrink-0 sticky top-20 h-fit"
            style={{
              width: '260px',
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              borderRadius: 'var(--radius-lg)',
              padding: '1.25rem',
              boxShadow: 'var(--shadow-sm)',
            }}
          >
            <SidebarContent />
          </div>

          {sidebarOpen && (
            <div
              className="lg:hidden fixed inset-0 z-40"
              style={{ background: 'rgba(0,0,0,0.5)' }}
              onClick={() => setSidebarOpen(false)}
            >
              <div
                className="absolute left-0 top-0 bottom-0 w-80 overflow-y-auto animate-fade-in"
                style={{ background: 'var(--bg-card)', padding: '1.5rem' }}
                onClick={e => e.stopPropagation()}
              >
                <div className="flex justify-between items-center mb-4">
                  <span
                    className="font-semibold"
                    style={{ color: 'var(--text-primary)' }}
                  >
                    Filtros
                  </span>
                  <button
                    onClick={() => setSidebarOpen(false)}
                    className="btn-ghost p-1"
                  >
                    <X size={18} />
                  </button>
                </div>
                <SidebarContent />
              </div>
            </div>
          )}

          <div className="flex-1 min-w-0">
            {loading ? (
              <div className="text-center py-20">
                <Search size={40} className="mx-auto mb-4" style={{ color: 'var(--text-muted)' }} />
                <h3
                  className="text-xl font-semibold mb-2"
                  style={{
                    fontFamily: 'var(--font-display)',
                    color: 'var(--text-primary)',
                  }}
                >
                  Cargando propiedades...
                </h3>
                <p style={{ color: 'var(--text-muted)' }}>
                  Estamos buscando los mejores resultados para vos.
                </p>
              </div>
            ) : results.length === 0 ? (
              <div className="text-center py-20">
                <Search size={40} className="mx-auto mb-4" style={{ color: 'var(--text-muted)' }} />
                <h3
                  className="text-xl font-semibold mb-2"
                  style={{
                    fontFamily: 'var(--font-display)',
                    color: 'var(--text-primary)',
                  }}
                >
                  Sin resultados
                </h3>
                <p className="mb-4" style={{ color: 'var(--text-muted)' }}>
                  Intenta ajustar los filtros o busca otro destino.
                </p>
                <button onClick={resetFilters} className="btn-primary">
                  Limpiar filtros
                </button>
              </div>
            ) : (
              <div
                className={
                  viewMode === 'grid'
                    ? 'grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5'
                    : 'flex flex-col gap-4'
                }
              >
                {results.map((property, i) => (
                  <div
                    key={property.id}
                    className="opacity-0 animate-fade-up"
                    style={{
                      animationFillMode: 'forwards',
                      animationDelay: `${Math.min(i, 6) * 0.05}s`,
                    }}
                  >
                    <PropertyCard
                      property={property}
                      compact={viewMode === 'list'}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function FilterSection({
  label,
  open,
  onToggle,
  children,
}: {
  label: string
  open: boolean
  onToggle: () => void
  children: ReactNode
}) {
  return (
    <div className="mb-5 pb-5 border-b" style={{ borderColor: 'var(--border)' }}>
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between mb-3"
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: 'var(--text-primary)',
          fontFamily: 'var(--font-body)',
          fontSize: '0.875rem',
          fontWeight: 600,
          padding: 0,
        }}
      >
        {label}
        {open ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
      </button>
      {open && children}
    </div>
  )
}

function FilterChip({
  label,
  onRemove,
}: {
  label: string
  onRemove: () => void
}) {
  return (
    <span
      className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium"
      style={{
        background: 'rgba(82,183,136,0.12)',
        color: 'var(--accent)',
        border: '1px solid rgba(82,183,136,0.25)',
      }}
    >
      {label}
      <button
        onClick={onRemove}
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: 'inherit',
          padding: 0,
          display: 'flex',
        }}
      >
        <X size={11} />
      </button>
    </span>
  )
}