const { createApp } = require('./src/app');
const { connectDatabase } = require('./src/config/database');
const { env } = require('./src/config/env');

async function startServer() {
  try {
    await connectDatabase();
    const app = createApp();
    app.listen(env.PORT, () => {
      console.log(`Servidor TicoStay corriendo en http://localhost:${env.PORT}`);
      console.log(`API base: http://localhost:${env.PORT}/api/v1`);
    });
  } catch (error) {
    console.error('No se pudo iniciar el servidor:', error.message);
    process.exit(1);
  }
}

startServer();
