function nextNumericId(items, field, prefix = '') {
  const max = items.reduce((highest, item) => {
    const rawValue = String(item[field] || '').replace(prefix, '');
    const numericValue = Number(rawValue);
    return Number.isFinite(numericValue) ? Math.max(highest, numericValue) : highest;
  }, 0);

  const next = max + 1;
  return prefix ? `${prefix}${String(next).padStart(3, '0')}` : String(next);
}

module.exports = { nextNumericId };
