const Property = require('../models/property.model');
const Booking = require('../models/booking.model');
const Review = require('../models/review.model');
const SiteSetting = require('../models/site-setting.model');
const { asyncHandler } = require('../utils/async-handler');
const { sendSuccess } = require('../utils/response');
const { AppError } = require('../utils/app-error');

const getDashboard = asyncHandler(async (req, res) => {
  const [settings, properties, bookings, reviews] = await Promise.all([
    SiteSetting.findOne({ key: 'main' }),
    Property.find({ isActive: true }).sort({ createdAt: -1 }),
    Booking.find().sort({ checkIn: 1 }),
    Review.find().sort({ date: -1 }),
  ]);

  if (!settings) {
    throw new AppError('No se encontró la configuración principal del sitio', 404);
  }

  return sendSuccess(res, {
    message: 'Dashboard cargado correctamente.',
    data: {
      stats: settings.adminStats,
      recentBookings: bookings.slice(0, 5).map((booking) => booking.toFrontendJSON()),
      pendingReviews: reviews.filter((review) => !review.approved).map((review) => review.toFrontendJSON()),
      properties: properties.map((property) => property.toFrontendJSON()),
    },
  });
});

const getSettings = asyncHandler(async (req, res) => {
  const settings = await SiteSetting.findOne({ key: 'main' });
  if (!settings) {
    throw new AppError('No se encontró la configuración del sitio.', 404);
  }

  return sendSuccess(res, {
    message: 'Configuración obtenida correctamente.',
    data: settings.toPayload(),
  });
});

const updateSettings = asyncHandler(async (req, res) => {
  const settings = await SiteSetting.findOne({ key: 'main' });
  if (!settings) {
    throw new AppError('No se encontró la configuración del sitio.', 404);
  }

  if (req.body.siteName !== undefined) settings.siteName = req.body.siteName;
  if (req.body.contactEmail !== undefined) settings.contactEmail = req.body.contactEmail;
  if (req.body.phone !== undefined) settings.phone = req.body.phone;
  if (req.body.adminStats !== undefined) settings.adminStats = { ...settings.adminStats.toObject(), ...req.body.adminStats };
  if (req.body.notifications !== undefined) settings.notifications = { ...settings.notifications.toObject(), ...req.body.notifications };

  await settings.save();

  return sendSuccess(res, {
    message: 'Configuración actualizada correctamente.',
    data: settings.toPayload(),
  });
});

const getBootstrap = asyncHandler(async (req, res) => {
  const [settings, properties, bookings, reviews] = await Promise.all([
    SiteSetting.findOne({ key: 'main' }),
    Property.find({ isActive: true }).sort({ createdAt: -1 }),
    Booking.find().sort({ checkIn: 1 }),
    Review.find().sort({ date: -1 }),
  ]);

  return sendSuccess(res, {
    message: 'Bootstrap cargado correctamente.',
    data: {
      site: settings ? settings.toPayload() : null,
      featuredProperties: properties.filter((property) => property.featured).slice(0, 3).map((property) => property.toFrontendJSON()),
      properties: properties.map((property) => property.toFrontendJSON()),
      bookings: bookings.map((booking) => booking.toFrontendJSON()),
      reviews: reviews.map((review) => review.toFrontendJSON()),
    },
  });
});

module.exports = { getDashboard, getSettings, updateSettings, getBootstrap };
