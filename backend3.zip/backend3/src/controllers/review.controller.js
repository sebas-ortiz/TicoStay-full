const Review = require('../models/review.model');
const Property = require('../models/property.model');
const { asyncHandler } = require('../utils/async-handler');
const { AppError } = require('../utils/app-error');
const { sendSuccess } = require('../utils/response');
const { nextNumericId } = require('../utils/id');

async function refreshPropertyRating(propertyId) {
  const property = await Property.findOne({ propertyId, isActive: true });
  if (!property) return null;

  const approvedReviews = await Review.find({ propertyId, approved: true });
  if (!approvedReviews.length) {
    property.rating = 0;
    property.reviewCount = 0;
  } else {
    const total = approvedReviews.reduce((sum, review) => sum + review.rating, 0);
    property.rating = Number((total / approvedReviews.length).toFixed(1));
    property.reviewCount = approvedReviews.length;
  }
  await property.save();
  return property;
}

const listReviews = asyncHandler(async (req, res) => {
  const { approved, propertyId } = req.query;
  let filter = { approved: true };

  if (approved !== undefined) {
    filter.approved = String(approved).toLowerCase() === 'true';
  }

  if (propertyId) {
    filter.propertyId = propertyId;
  }

  const reviews = await Review.find(filter).sort({ date: -1 });

  return sendSuccess(res, {
    message: 'Reseñas obtenidas correctamente.',
    data: reviews.map((review) => review.toFrontendJSON()),
    meta: { count: reviews.length },
  });
});

const createReview = asyncHandler(async (req, res) => {
  const { propertyId, guest, rating, comment } = req.body;

  if (!propertyId || !guest || !rating || !comment) {
    throw new AppError('propertyId, guest, rating y comment son obligatorios.', 400);
  }

  const property = await Property.findOne({ propertyId, isActive: true });
  if (!property) {
    throw new AppError('La propiedad indicada no existe.', 404);
  }

  const existing = await Review.find().select('reviewId');
  const reviewId = nextNumericId(existing, 'reviewId', 'R');

  const review = await Review.create({
    reviewId,
    propertyId,
    property: property.name,
    guest,
    rating: Number(rating),
    comment,
    approved: req.user && req.user.role === 'admin',
  });

  if (review.approved) {
    await refreshPropertyRating(propertyId);
  }

  return sendSuccess(res, {
    statusCode: 201,
    message: 'Reseña enviada correctamente.',
    data: review.toFrontendJSON(),
  });
});

const approveReview = asyncHandler(async (req, res) => {
  const review = await Review.findOne({ reviewId: req.params.id });
  if (!review) {
    throw new AppError('Reseña no encontrada.', 404);
  }

  review.approved = true;
  await review.save();
  await refreshPropertyRating(review.propertyId);

  return sendSuccess(res, {
    message: 'Reseña aprobada correctamente.',
    data: review.toFrontendJSON(),
  });
});

const rejectReview = asyncHandler(async (req, res) => {
  const review = await Review.findOneAndDelete({ reviewId: req.params.id });
  if (!review) {
    throw new AppError('Reseña no encontrada.', 404);
  }

  await refreshPropertyRating(review.propertyId);

  return sendSuccess(res, {
    message: 'Reseña rechazada correctamente.',
    data: review.toFrontendJSON(),
  });
});

module.exports = {
  listReviews,
  createReview,
  approveReview,
  rejectReview,
};
