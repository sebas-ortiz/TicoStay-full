const Booking = require('../models/booking.model');
const Property = require('../models/property.model');
const { asyncHandler } = require('../utils/async-handler');
const { AppError } = require('../utils/app-error');
const { sendSuccess } = require('../utils/response');
const { nextNumericId } = require('../utils/id');

const listBookings = asyncHandler(async (req, res) => {
  const { status, guestEmail, propertyId } = req.query;
  let bookings = await Booking.find().sort({ checkIn: 1 });

  if (req.user.role !== 'admin') {
    bookings = bookings.filter((booking) => booking.guestEmail === req.user.email);
  }

  if (status) bookings = bookings.filter((booking) => booking.status === status);
  if (guestEmail) bookings = bookings.filter((booking) => booking.guestEmail === String(guestEmail).toLowerCase());
  if (propertyId) bookings = bookings.filter((booking) => booking.propertyId === propertyId);

  return sendSuccess(res, {
    message: 'Reservas obtenidas correctamente.',
    data: bookings.map((booking) => booking.toFrontendJSON()),
    meta: { count: bookings.length },
  });
});

const getBookingById = asyncHandler(async (req, res) => {
  const booking = await Booking.findOne({ bookingId: req.params.id });
  if (!booking) {
    throw new AppError('Reserva no encontrada.', 404);
  }

  if (req.user.role !== 'admin' && booking.guestEmail !== req.user.email) {
    throw new AppError('No tienes permisos para ver esta reserva.', 403);
  }

  return sendSuccess(res, {
    message: 'Reserva obtenida correctamente.',
    data: booking.toFrontendJSON(),
  });
});

const createBooking = asyncHandler(async (req, res) => {
  const { propertyId, checkIn, checkOut, guests = 1, guestName, guestEmail } = req.body;

  if (!propertyId || !checkIn || !checkOut || !guestName || !guestEmail) {
    throw new AppError('propertyId, checkIn, checkOut, guestName y guestEmail son obligatorios.', 400);
  }

  const property = await Property.findOne({ propertyId, isActive: true });
  if (!property) {
    throw new AppError('La propiedad indicada no existe.', 404);
  }

  const checkInDate = new Date(checkIn);
  const checkOutDate = new Date(checkOut);
  if (Number.isNaN(checkInDate.getTime()) || Number.isNaN(checkOutDate.getTime())) {
    throw new AppError('Las fechas son inválidas.', 400);
  }
  if (checkOutDate <= checkInDate) {
    throw new AppError('La fecha de salida debe ser posterior a la fecha de entrada.', 400);
  }

  const nights = Math.ceil((checkOutDate - checkInDate) / (1000 * 60 * 60 * 24));
  const total = req.body.total ? Number(req.body.total) : nights * property.price;

  const existing = await Booking.find().select('bookingId');
  const bookingId = nextNumericId(existing, 'bookingId', 'B');

  const booking = await Booking.create({
    bookingId,
    userId: req.user ? req.user.userId : null,
    guestName,
    guestEmail: String(guestEmail).toLowerCase(),
    propertyId,
    propertyName: property.name,
    checkIn: checkInDate,
    checkOut: checkOutDate,
    guests: Number(guests),
    total,
    status: req.user && req.user.role === 'admin' ? 'confirmed' : 'pending',
  });

  return sendSuccess(res, {
    statusCode: 201,
    message: 'Reserva creada correctamente.',
    data: booking.toFrontendJSON(),
  });
});

const updateBookingStatus = asyncHandler(async (req, res) => {
  const booking = await Booking.findOne({ bookingId: req.params.id });
  if (!booking) {
    throw new AppError('Reserva no encontrada.', 404);
  }

  const validStatuses = ['confirmed', 'pending', 'cancelled'];
  if (!validStatuses.includes(req.body.status)) {
    throw new AppError('Estado de reserva inválido.', 400);
  }

  booking.status = req.body.status;
  await booking.save();

  return sendSuccess(res, {
    message: 'Estado de la reserva actualizado correctamente.',
    data: booking.toFrontendJSON(),
  });
});

const deleteBooking = asyncHandler(async (req, res) => {
  const booking = await Booking.findOneAndDelete({ bookingId: req.params.id });
  if (!booking) {
    throw new AppError('Reserva no encontrada.', 404);
  }

  return sendSuccess(res, {
    message: 'Reserva eliminada correctamente.',
    data: booking.toFrontendJSON(),
  });
});

module.exports = {
  listBookings,
  getBookingById,
  createBooking,
  updateBookingStatus,
  deleteBooking,
};
