const mongoose = require('mongoose');
const { sendSuccess } = require('../utils/response');

function getHealth(req, res) {
  return sendSuccess(res, {
    message: 'Health check OK',
    data: {
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || 'development',
      database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    },
  });
}

module.exports = { getHealth };
