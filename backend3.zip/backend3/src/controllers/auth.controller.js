const User = require('../models/user.model');
const { asyncHandler } = require('../utils/async-handler');
const { AppError } = require('../utils/app-error');
const { sendSuccess } = require('../utils/response');
const { hashPassword, comparePassword } = require('../utils/password');
const { signToken } = require('../utils/token');
const { nextNumericId } = require('../utils/id');

const register = asyncHandler(async (req, res) => {
  const { name, email, password, role = 'user' } = req.body;

  if (!name || !email || !password) {
    throw new AppError('Nombre, correo y contraseña son obligatorios.', 400);
  }

  if (password.length < 6) {
    throw new AppError('La contraseña debe tener al menos 6 caracteres.', 400);
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const existingUser = await User.findOne({ email: normalizedEmail });
  if (existingUser) {
    throw new AppError('Ya existe una cuenta con ese correo.', 409);
  }

  const users = await User.find().select('userId');
  const userId = nextNumericId(users, 'userId');
  const passwordHash = await hashPassword(password);

  const user = await User.create({
    userId,
    name: String(name).trim(),
    email: normalizedEmail,
    passwordHash,
    role: role === 'admin' ? 'admin' : 'user',
  });

  const token = signToken({ userId: user.userId, role: user.role, email: user.email });

  return sendSuccess(res, {
    statusCode: 201,
    message: 'Cuenta creada correctamente.',
    data: {
      user: user.toSafeJSON(),
      token,
    },
  });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    throw new AppError('Correo y contraseña son obligatorios.', 400);
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const user = await User.findOne({ email: normalizedEmail, isActive: true });

  if (!user) {
    throw new AppError('Correo o contraseña incorrectos.', 401);
  }

  const isValidPassword = await comparePassword(password, user.passwordHash);
  if (!isValidPassword) {
    throw new AppError('Correo o contraseña incorrectos.', 401);
  }

  const token = signToken({ userId: user.userId, role: user.role, email: user.email });

  return sendSuccess(res, {
    message: 'Inicio de sesión exitoso.',
    data: {
      user: user.toSafeJSON(),
      token,
    },
  });
});

const me = asyncHandler(async (req, res) => {
  return sendSuccess(res, {
    message: 'Usuario autenticado.',
    data: req.user.toSafeJSON(),
  });
});

module.exports = { register, login, me };
