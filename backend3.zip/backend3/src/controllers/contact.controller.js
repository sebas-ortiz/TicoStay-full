const Contact = require('../models/contact.model');
const { asyncHandler } = require('../utils/async-handler');
const { AppError } = require('../utils/app-error');
const { sendSuccess } = require('../utils/response');
const { nextNumericId } = require('../utils/id');

const getContacts = asyncHandler(async (req, res) => {
  const contacts = await Contact.find().sort({ createdAt: -1 });
  return sendSuccess(res, {
    message: 'Mensajes de contacto obtenidos correctamente.',
    data: contacts.map((contact) => contact.toJSONPayload()),
    meta: { count: contacts.length },
  });
});

const createContact = asyncHandler(async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    throw new AppError('name, email y message son obligatorios.', 400);
  }

  const contacts = await Contact.find().select('contactId');
  const contactId = nextNumericId(contacts, 'contactId', 'C');

  const contact = await Contact.create({
    contactId,
    name,
    email,
    phone: req.body.phone || '',
    subject: req.body.subject || '',
    message,
    status: 'new',
  });

  return sendSuccess(res, {
    statusCode: 201,
    message: 'Mensaje enviado correctamente.',
    data: contact.toJSONPayload(),
  });
});

const getContactById = asyncHandler(async (req, res) => {
  const contact = await Contact.findOne({ contactId: req.params.id });
  if (!contact) {
    throw new AppError('Mensaje no encontrado.', 404);
  }

  return sendSuccess(res, {
    message: 'Mensaje obtenido correctamente.',
    data: contact.toJSONPayload(),
  });
});

const updateContactStatus = asyncHandler(async (req, res) => {
  const contact = await Contact.findOne({ contactId: req.params.id });
  if (!contact) {
    throw new AppError('Mensaje no encontrado.', 404);
  }

  const validStatuses = ['new', 'read', 'resolved'];
  if (!validStatuses.includes(req.body.status)) {
    throw new AppError('Estado inválido para el mensaje.', 400);
  }

  contact.status = req.body.status;
  await contact.save();

  return sendSuccess(res, {
    message: 'Estado del mensaje actualizado correctamente.',
    data: contact.toJSONPayload(),
  });
});

const deleteContact = asyncHandler(async (req, res) => {
  const contact = await Contact.findOneAndDelete({ contactId: req.params.id });
  if (!contact) {
    throw new AppError('Mensaje no encontrado.', 404);
  }

  return sendSuccess(res, {
    message: 'Mensaje eliminado correctamente.',
    data: contact.toJSONPayload(),
  });
});

module.exports = {
  getContacts,
  createContact,
  getContactById,
  updateContactStatus,
  deleteContact,
};
