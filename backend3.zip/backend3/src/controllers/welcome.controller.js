const mongoose = require('mongoose');
const { sendSuccess } = require('../utils/response');
const { REGIONS } = require('../data/seed-content');

function getWelcome(req, res) {
  return sendSuccess(res, {
    message: 'Bienvenido a la API de TicoStay',
    data: {
      status: 'online',
      database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
      regions: REGIONS,
      modules: ['auth', 'properties', 'bookings', 'reviews', 'admin', 'contact'],
    },
  });
}

module.exports = { getWelcome };
