const Property = require('../models/property.model');
const Review = require('../models/review.model');
const { REGIONS } = require('../data/seed-content');
const { asyncHandler } = require('../utils/async-handler');
const { sendSuccess } = require('../utils/response');
const { AppError } = require('../utils/app-error');
const { normalizeCsvParam, toBoolean } = require('../utils/query');
const { nextNumericId } = require('../utils/id');

function applySort(list, sort) {
  switch (sort) {
    case 'price-asc':
      return list.sort((a, b) => a.price - b.price);
    case 'price-desc':
      return list.sort((a, b) => b.price - a.price);
    case 'rating':
      return list.sort((a, b) => b.rating - a.rating);
    case 'newest':
      return list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    default:
      return list;
  }
}

const listProperties = asyncHandler(async (req, res) => {
  const properties = await Property.find({ isActive: true }).sort({ createdAt: -1 });

  const query = String(req.query.q || '').trim().toLowerCase();
  const regions = normalizeCsvParam(req.query.region);
  const types = normalizeCsvParam(req.query.type);
  const amenities = normalizeCsvParam(req.query.amenities).map((item) => item.toLowerCase());
  const ecoOnly = toBoolean(req.query.ecoOnly);
  const featured = toBoolean(req.query.featured);
  const minRating = Number(req.query.minRating || 0);
  const minPrice = Number(req.query.minPrice || 0);
  const maxPrice = Number(req.query.maxPrice || Number.MAX_SAFE_INTEGER);
  const guests = Number(req.query.guests || 0);
  const sort = String(req.query.sort || 'relevance');

  let filtered = properties.filter((property) => property.isActive);

  if (query) {
    filtered = filtered.filter((property) => {
      const haystack = [
        property.name,
        property.location,
        property.region,
        property.type,
        property.description,
        ...property.amenities,
      ]
        .join(' ')
        .toLowerCase();

      return haystack.includes(query);
    });
  }

  if (regions.length) filtered = filtered.filter((property) => regions.includes(property.region));
  if (types.length) filtered = filtered.filter((property) => types.includes(property.type));
  if (ecoOnly) filtered = filtered.filter((property) => property.ecoFriendly);
  if (featured) filtered = filtered.filter((property) => property.featured);
  if (guests) filtered = filtered.filter((property) => property.maxGuests >= guests);
  filtered = filtered.filter((property) => property.price >= minPrice && property.price <= maxPrice);
  filtered = filtered.filter((property) => property.rating >= minRating);

  if (amenities.length) {
    filtered = filtered.filter((property) =>
      amenities.every((amenity) => property.amenities.some((value) => value.toLowerCase().includes(amenity)))
    );
  }

  filtered = applySort(filtered, sort);

  return sendSuccess(res, {
    message: 'Propiedades obtenidas correctamente.',
    data: filtered.map((property) => property.toFrontendJSON()),
    meta: {
      count: filtered.length,
      availableRegions: REGIONS,
    },
  });
});

const getPropertyById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const property = await Property.findOne({ propertyId: id, isActive: true });

  if (!property) {
    throw new AppError('Propiedad no encontrada.', 404);
  }

  const reviews = await Review.find({ propertyId: id, approved: true }).sort({ date: -1 });

  return sendSuccess(res, {
    message: 'Detalle de propiedad obtenido correctamente.',
    data: {
      ...property.toFrontendJSON(),
      reviews: reviews.map((review) => review.toFrontendJSON()),
    },
  });
});

const createProperty = asyncHandler(async (req, res) => {
  const requiredFields = ['name', 'type', 'location', 'region', 'price', 'image', 'description', 'maxGuests', 'bedrooms', 'bathrooms'];
  for (const field of requiredFields) {
    if (req.body[field] === undefined || req.body[field] === null || req.body[field] === '') {
      throw new AppError(`El campo ${field} es obligatorio.`, 400);
    }
  }

  const properties = await Property.find().select('propertyId');
  const propertyId = nextNumericId(properties, 'propertyId');

  const property = await Property.create({
    propertyId,
    name: req.body.name,
    type: req.body.type,
    location: req.body.location,
    region: req.body.region,
    price: Number(req.body.price),
    rating: Number(req.body.rating || 0),
    reviewCount: Number(req.body.reviewCount || 0),
    image: req.body.image,
    images: Array.isArray(req.body.images) ? req.body.images : req.body.image ? [req.body.image] : [],
    amenities: Array.isArray(req.body.amenities) ? req.body.amenities : [],
    description: req.body.description,
    featured: Boolean(req.body.featured),
    ecoFriendly: Boolean(req.body.ecoFriendly),
    maxGuests: Number(req.body.maxGuests),
    bedrooms: Number(req.body.bedrooms),
    bathrooms: Number(req.body.bathrooms),
  });

  return sendSuccess(res, {
    statusCode: 201,
    message: 'Propiedad creada correctamente.',
    data: property.toFrontendJSON(),
  });
});

const updateProperty = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const property = await Property.findOne({ propertyId: id, isActive: true });

  if (!property) {
    throw new AppError('Propiedad no encontrada.', 404);
  }

  Object.assign(property, {
    ...req.body,
    price: req.body.price !== undefined ? Number(req.body.price) : property.price,
    rating: req.body.rating !== undefined ? Number(req.body.rating) : property.rating,
    reviewCount: req.body.reviewCount !== undefined ? Number(req.body.reviewCount) : property.reviewCount,
    maxGuests: req.body.maxGuests !== undefined ? Number(req.body.maxGuests) : property.maxGuests,
    bedrooms: req.body.bedrooms !== undefined ? Number(req.body.bedrooms) : property.bedrooms,
    bathrooms: req.body.bathrooms !== undefined ? Number(req.body.bathrooms) : property.bathrooms,
  });

  await property.save();

  return sendSuccess(res, {
    message: 'Propiedad actualizada correctamente.',
    data: property.toFrontendJSON(),
  });
});

const deleteProperty = asyncHandler(async (req, res) => {
  const property = await Property.findOne({ propertyId: req.params.id, isActive: true });
  if (!property) {
    throw new AppError('Propiedad no encontrada.', 404);
  }

  property.isActive = false;
  await property.save();

  return sendSuccess(res, {
    message: 'Propiedad eliminada correctamente.',
    data: property.toFrontendJSON(),
  });
});

module.exports = {
  listProperties,
  getPropertyById,
  createProperty,
  updateProperty,
  deleteProperty,
};
