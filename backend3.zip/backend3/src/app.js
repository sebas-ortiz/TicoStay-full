const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const routes = require('./routes');
const { notFoundHandler, errorHandler } = require('./middlewares/error.middleware');
const { env } = require('./config/env');

function createCorsOptions() {
  const allowedOrigins = env.CLIENT_ORIGIN.split(',').map((value) => value.trim()).filter(Boolean);

  if (allowedOrigins.includes('*')) {
    return { origin: true, credentials: true };
  }

  return {
    origin(origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error(`Origen no permitido por CORS: ${origin}`));
    },
    credentials: true,
  };
}

function createApp() {
  const app = express();

  app.use(cors(createCorsOptions()));
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

  app.get('/', (req, res) => {
    res.json({
      success: true,
      message: 'TicoStay API en línea',
      version: '2.0.0',
      docs: '/api/v1',
    });
  });

  app.use('/api/v1', routes);
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

module.exports = { createApp };
