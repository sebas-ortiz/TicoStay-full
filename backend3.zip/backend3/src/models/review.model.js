const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema(
  {
    reviewId: { type: String, required: true, unique: true, index: true },
    guest: { type: String, required: true, trim: true },
    propertyId: { type: String, required: true, ref: 'Property' },
    property: { type: String, required: true, trim: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, required: true, trim: true },
    date: { type: Date, required: true, default: Date.now },
    approved: { type: Boolean, default: false },
  },
  { timestamps: true }
);

reviewSchema.methods.toFrontendJSON = function toFrontendJSON() {
  return {
    id: this.reviewId,
    guest: this.guest,
    propertyId: this.propertyId,
    property: this.property,
    rating: this.rating,
    comment: this.comment,
    date: this.date.toISOString().split('T')[0],
    approved: this.approved,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model('Review', reviewSchema);
