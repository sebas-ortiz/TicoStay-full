const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema(
  {
    bookingId: { type: String, required: true, unique: true, index: true },
    userId: { type: String, ref: 'User', default: null },
    guestName: { type: String, required: true, trim: true },
    guestEmail: { type: String, required: true, trim: true, lowercase: true },
    propertyId: { type: String, required: true, ref: 'Property' },
    propertyName: { type: String, required: true, trim: true },
    checkIn: { type: Date, required: true },
    checkOut: { type: Date, required: true },
    guests: { type: Number, default: 1, min: 1 },
    total: { type: Number, required: true, min: 0 },
    status: { type: String, enum: ['confirmed', 'pending', 'cancelled'], default: 'pending' },
  },
  { timestamps: true }
);

bookingSchema.methods.toFrontendJSON = function toFrontendJSON() {
  return {
    id: this.bookingId,
    guest: this.guestName,
    guestEmail: this.guestEmail,
    propertyId: this.propertyId,
    property: this.propertyName,
    checkIn: this.checkIn.toISOString().split('T')[0],
    checkOut: this.checkOut.toISOString().split('T')[0],
    guests: this.guests,
    status: this.status,
    total: this.total,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model('Booking', bookingSchema);
