const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema(
  {
    propertyId: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true, trim: true },
    type: {
      type: String,
      required: true,
      enum: ['hotel', 'eco-lodge', 'villa', 'cabaña', 'apartamento'],
    },
    location: { type: String, required: true, trim: true },
    region: { type: String, required: true, trim: true, index: true },
    price: { type: Number, required: true, min: 0 },
    rating: { type: Number, default: 0, min: 0, max: 5 },
    reviewCount: { type: Number, default: 0, min: 0 },
    image: { type: String, required: true, trim: true },
    images: { type: [String], default: [] },
    amenities: { type: [String], default: [] },
    description: { type: String, required: true, trim: true },
    featured: { type: Boolean, default: false },
    ecoFriendly: { type: Boolean, default: false },
    maxGuests: { type: Number, required: true, min: 1 },
    bedrooms: { type: Number, required: true, min: 1 },
    bathrooms: { type: Number, required: true, min: 1 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

propertySchema.methods.toFrontendJSON = function toFrontendJSON() {
  return {
    id: this.propertyId,
    name: this.name,
    type: this.type,
    location: this.location,
    region: this.region,
    price: this.price,
    rating: this.rating,
    reviewCount: this.reviewCount,
    image: this.image,
    images: this.images,
    amenities: this.amenities,
    description: this.description,
    featured: this.featured,
    ecoFriendly: this.ecoFriendly,
    maxGuests: this.maxGuests,
    bedrooms: this.bedrooms,
    bathrooms: this.bathrooms,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model('Property', propertySchema);
