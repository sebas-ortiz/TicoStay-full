const mongoose = require('mongoose');

const siteSettingSchema = new mongoose.Schema(
  {
    key: { type: String, required: true, unique: true, index: true },
    siteName: { type: String, default: 'TicoStay' },
    contactEmail: { type: String, default: 'hola@ticostay.cr' },
    phone: { type: String, default: '+506 2222-3333' },
    adminStats: {
      totalProperties: { type: Number, default: 24 },
      activeBookings: { type: Number, default: 87 },
      monthlyRevenue: { type: Number, default: 48320 },
      occupancyRate: { type: Number, default: 73 },
      newReviews: { type: Number, default: 12 },
      pendingApprovals: { type: Number, default: 3 },
    },
    notifications: {
      newBooking: { type: Boolean, default: true },
      pendingReview: { type: Boolean, default: true },
      newProperty: { type: Boolean, default: true },
      cancelledBooking: { type: Boolean, default: true },
    },
  },
  { timestamps: true }
);

siteSettingSchema.methods.toPayload = function toPayload() {
  return {
    siteName: this.siteName,
    contactEmail: this.contactEmail,
    phone: this.phone,
    adminStats: this.adminStats,
    notifications: this.notifications,
    createdAt: this.createdAt,
    updatedAt: this.updatedAt,
  };
};

module.exports = mongoose.model('SiteSetting', siteSettingSchema);
