const express = require('express');
const {
  getContacts,
  createContact,
  getContactById,
  updateContactStatus,
  deleteContact,
} = require('../controllers/contact.controller');
const { requireAuth, requireAdmin } = require('../middlewares/auth.middleware');

const router = express.Router();
router.get('/', requireAuth, requireAdmin, getContacts);
router.post('/', createContact);
router.get('/:id', requireAuth, requireAdmin, getContactById);
router.patch('/:id/status', requireAuth, requireAdmin, updateContactStatus);
router.delete('/:id', requireAuth, requireAdmin, deleteContact);

module.exports = router;
