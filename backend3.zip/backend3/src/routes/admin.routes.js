const express = require('express');
const { getDashboard, getSettings, updateSettings } = require('../controllers/admin.controller');
const { requireAuth, requireAdmin } = require('../middlewares/auth.middleware');

const router = express.Router();
router.get('/dashboard', requireAuth, requireAdmin, getDashboard);
router.get('/settings', requireAuth, requireAdmin, getSettings);
router.put('/settings', requireAuth, requireAdmin, updateSettings);

module.exports = router;
