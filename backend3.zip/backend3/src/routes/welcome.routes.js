const express = require('express');
const { getWelcome } = require('../controllers/welcome.controller');

const router = express.Router();
router.get('/', getWelcome);

module.exports = router;
