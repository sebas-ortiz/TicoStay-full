const express = require('express');
const {
  listBookings,
  getBookingById,
  createBooking,
  updateBookingStatus,
  deleteBooking,
} = require('../controllers/booking.controller');
const { requireAuth, requireAdmin } = require('../middlewares/auth.middleware');

const router = express.Router();
router.get('/', requireAuth, listBookings);
router.get('/:id', requireAuth, getBookingById);
router.post('/', requireAuth, createBooking);
router.patch('/:id/status', requireAuth, requireAdmin, updateBookingStatus);
router.delete('/:id', requireAuth, requireAdmin, deleteBooking);

module.exports = router;
