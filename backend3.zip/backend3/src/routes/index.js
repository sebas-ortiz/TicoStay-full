const express = require('express');
const welcomeRoutes = require('./welcome.routes');
const healthRoutes = require('./health.routes');
const authRoutes = require('./auth.routes');
const propertyRoutes = require('./property.routes');
const bookingRoutes = require('./booking.routes');
const reviewRoutes = require('./review.routes');
const adminRoutes = require('./admin.routes');
const contactRoutes = require('./contact.routes');
const { getBootstrap } = require('../controllers/admin.controller');

const router = express.Router();

router.get('/bootstrap', getBootstrap);
router.use('/welcome', welcomeRoutes);
router.use('/health', healthRoutes);
router.use('/auth', authRoutes);
router.use('/properties', propertyRoutes);
router.use('/bookings', bookingRoutes);
router.use('/reviews', reviewRoutes);
router.use('/admin', adminRoutes);
router.use('/contact', contactRoutes);

module.exports = router;
