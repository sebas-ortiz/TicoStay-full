const express = require('express');
const { getHealth } = require('../controllers/health.controller');
const { getBootstrap } = require('../controllers/admin.controller');

const router = express.Router();
router.get('/', getHealth);
router.get('/bootstrap', getBootstrap);

module.exports = router;
