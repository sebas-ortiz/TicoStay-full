const express = require('express');
const {
  listProperties,
  getPropertyById,
  createProperty,
  updateProperty,
  deleteProperty,
} = require('../controllers/property.controller');
const { requireAuth, requireAdmin } = require('../middlewares/auth.middleware');

const router = express.Router();
router.get('/', listProperties);
router.get('/:id', getPropertyById);
router.post('/', requireAuth, requireAdmin, createProperty);
router.put('/:id', requireAuth, requireAdmin, updateProperty);
router.delete('/:id', requireAuth, requireAdmin, deleteProperty);

module.exports = router;
