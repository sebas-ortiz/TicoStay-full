const express = require('express');
const {
  listReviews,
  createReview,
  approveReview,
  rejectReview,
} = require('../controllers/review.controller');
const { requireAuth, requireAdmin } = require('../middlewares/auth.middleware');

const router = express.Router();
router.get('/', listReviews);
router.post('/', requireAuth, createReview);
router.patch('/:id/approve', requireAuth, requireAdmin, approveReview);
router.patch('/:id/reject', requireAuth, requireAdmin, rejectReview);

module.exports = router;
