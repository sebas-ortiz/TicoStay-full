const User = require('../models/user.model');
const { verifyToken } = require('../utils/token');
const { AppError } = require('../utils/app-error');
const { asyncHandler } = require('../utils/async-handler');

const requireAuth = asyncHandler(async (req, res, next) => {
  const authHeader = req.headers.authorization || '';

  if (!authHeader.startsWith('Bearer ')) {
    throw new AppError('No autorizado. Debes enviar un token Bearer.', 401);
  }

  const token = authHeader.replace('Bearer ', '').trim();

  let payload;
  try {
    payload = verifyToken(token);
  } catch (error) {
    throw new AppError('Token inválido o expirado.', 401);
  }

  const user = await User.findOne({ userId: payload.userId, isActive: true });
  if (!user) {
    throw new AppError('Usuario no válido o inactivo.', 401);
  }

  req.user = user;
  req.tokenPayload = payload;
  next();
});

function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return next(new AppError('No tienes permisos para realizar esta acción.', 403));
  }
  return next();
}

module.exports = { requireAuth, requireAdmin };
