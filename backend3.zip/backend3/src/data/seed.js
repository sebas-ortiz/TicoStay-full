const { connectDatabase, disconnectDatabase } = require('../config/database');
const User = require('../models/user.model');
const Property = require('../models/property.model');
const Booking = require('../models/booking.model');
const Review = require('../models/review.model');
const Contact = require('../models/contact.model');
const SiteSetting = require('../models/site-setting.model');
const { hashPassword } = require('../utils/password');
const {
  PROPERTY_SEED,
  USER_SEED,
  BOOKING_SEED,
  REVIEW_SEED,
  CONTACT_SEED,
  SITE_SETTING_SEED,
} = require('./seed-content');

async function seed() {
  await connectDatabase();

  await Promise.all([
    User.deleteMany({}),
    Property.deleteMany({}),
    Booking.deleteMany({}),
    Review.deleteMany({}),
    Contact.deleteMany({}),
    SiteSetting.deleteMany({}),
  ]);

  const usersToInsert = [];
for (const user of USER_SEED) {
  usersToInsert.push({
    userId: user.userId,
    name: user.name,
    email: user.email,
    role: user.role,
    passwordHash: await hashPassword(user.password),
  });
}

const propertiesToInsert = PROPERTY_SEED.map((property, index) => ({
  ...property,
  propertyId: property.propertyId ?? String(index + 1),
}));

await User.insertMany(usersToInsert);
await Property.insertMany(propertiesToInsert);
await Booking.insertMany(BOOKING_SEED);
await Review.insertMany(REVIEW_SEED);
await Contact.insertMany(CONTACT_SEED);
await SiteSetting.create(SITE_SETTING_SEED);

  console.log('Seed completado correctamente.');
  console.log('Admin: admin@ticostay.cr / 123456');
  console.log('User: user@ticostay.cr / 123456');
}

seed()
  .catch((error) => {
    console.error('Error ejecutando seed:', error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await disconnectDatabase();
  });
